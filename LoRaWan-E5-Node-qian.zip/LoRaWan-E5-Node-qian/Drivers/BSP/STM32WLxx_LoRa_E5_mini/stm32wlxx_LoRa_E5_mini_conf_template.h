/**
  ******************************************************************************
  * @file    stm32wlxx_LoRa_E5_mini_conf.h
  * @author  MCD Application Team
  * @brief   STM32WLxx_LoRa_E5_mini board configuration file.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2020(-2021) STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef STM32WLXX_LORA_E5_MINI_CONF_H
#define STM32WLXX_LORA_E5_MINI_CONF_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32wlxx_hal.h"

/** @addtogroup BSP
  * @{
  */

/** @addtogroup STM32WLXX_LoRa_E5_mini
  * @{
  */

/** @defgroup STM32WLXX_LoRa_E5_mini_CONFIG CONFIG
  * @{
  */

/** @defgroup STM32WLXX_LoRa_E5_mini_CONFIG_Exported_Constants Exported Constants
  * @{
  */
/* COM usage define */
#define USE_BSP_COM_FEATURE                 0U

/* COM log define */
#define USE_COM_LOG                         0U

/* IRQ priorities */
#define BSP_BUTTON_SWx_IT_PRIORITY         15U

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#ifdef __cplusplus
}
#endif

#endif /* STM32WLXX_LoRa_E5_mini_CONF_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
